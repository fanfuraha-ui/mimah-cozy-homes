# Mima Cozy Homes

*Stay • Relax • Feel at Home*

Website for Mima Cozy Homes serviced apartments. Built from the Whitehouse Stays site (same layout and booking flow); the Whitehouse Stays repo is left unchanged for reference.
Single-file site. Photos are served as WebP with JPEG fallback. Guests choose a branch, dates and apartment, and the form opens WhatsApp with the booking message ready to send.

## What is in this repo
- `index.html` holds everything (HTML, CSS, JS). Edit the `CONFIG` object at the bottom of the script for phones, branches, apartments, prices, photos and the video.
- `images/` holds the photos and the video.

## Put it online
**GitHub Pages:** Settings, Pages, deploy from branch `main`, folder `/ (root)`.
**Any hosting provider (cPanel):** upload `index.html` and the `images` folder into `public_html`.

## Still carried over from Whitehouse Stays (replace before launch)
- Phone and WhatsApp numbers in `CONFIG.phones` / `CONFIG.whatsapp`.
- Branches (Migori, Kisumu – Makasembo), landmarks and map links in `CONFIG.branches`, plus the branch text in the page and the JSON-LD address.
- All photos in `images/` and the apartment tour video.
- Prices: set `price:` on each apartment in `CONFIG`.
